/* eslint-disable react/prop-types */
const CardText = ({text}) => {
    return (
        <p className="text-white">{text}</p>
    )
}

export default CardText;